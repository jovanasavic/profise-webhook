//==============================================================================
// Copyright (c) Profisee Corporation. All Rights Reserved.
//==============================================================================

namespace Profisee.WebhookTemplate.Clients.Dtos
{
    internal class EntityDto
    {
        public IdentifierDto Identifier { get; set; }
    }
}
