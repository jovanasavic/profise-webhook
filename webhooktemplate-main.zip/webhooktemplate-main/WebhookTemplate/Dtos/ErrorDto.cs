//==============================================================================
// Copyright (c) Profisee Corporation. All Rights Reserved.
//==============================================================================

namespace Profisee.WebhookTemplate.Dtos
{
    internal  class ErrorDto
    {
        public int Code { get; set; }
        public string Message { get; set; }
    }
}
